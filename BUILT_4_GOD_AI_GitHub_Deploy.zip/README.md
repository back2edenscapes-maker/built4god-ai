# BUILT 4 GOD AI

**Built with purpose. Guided by faith.**

## Agent 01 — Scout
A free, scheduled public RSS monitor that collects and keyword-ranks technology/business headlines. Results are leads for manual validation, **not guaranteed earning opportunities**. It does not interact with rewards sites or automate paid tasks.

### Setup
1. Upload these files into your GitHub repository, preserving `.github/workflows/scout.yml`.
2. Open **Actions → Scout Research → Run workflow** to test.
3. After a successful run, download `scout-report` from the run's Artifacts section.

Runs daily at approximately 13:17 UTC. GitHub scheduled runs can be delayed or disabled after inactivity. This prototype requires no paid AI API.

Do not commit passwords, API keys, or personal customer data to a public repository.
