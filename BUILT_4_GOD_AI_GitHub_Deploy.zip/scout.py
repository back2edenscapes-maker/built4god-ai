import json, urllib.request, xml.etree.ElementTree as ET
from datetime import datetime, timezone
from pathlib import Path
SOURCES={'GitHub Blog':'https://github.blog/feed/','Hacker News':'https://hnrss.org/newest?points=50'}
WORDS={'automation':4,'api':3,'open source':3,'agent':3,'business':2,'free':1}
items=[];errors=[]
for name,url in SOURCES.items():
 try:
  req=urllib.request.Request(url,headers={'User-Agent':'Built4GodAI-Scout/1.0'})
  with urllib.request.urlopen(req,timeout=20) as r: data=r.read(1500000)
  root=ET.fromstring(data)
  for item in root.findall('.//item')[:40]:
   title=item.findtext('title','').strip();link=item.findtext('link','').strip()
   if title and link: items.append({'source':name,'title':title,'url':link,'score':sum(v for k,v in WORDS.items() if k in title.lower())})
 except Exception as e:errors.append({'source':name,'error':str(e)[:150]})
items=sorted({x['url']:x for x in items}.values(),key=lambda x:-x['score'])[:30]
Path('output').mkdir(exist_ok=True)
Path('output/scout-report.json').write_text(json.dumps({'generated_at':datetime.now(timezone.utc).isoformat(),'items':items,'errors':errors,'note':'News leads only; validate legitimacy, platform rules and demand before acting.'},indent=2))
print(f'{len(items)} items, {len(errors)} errors')
if not items:raise SystemExit('No RSS results')
